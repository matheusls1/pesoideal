﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BancoDeDadosTI13N
{
    class Program
    {
        static void Main(string[] args)
        {
            Menu men = new Menu();
            men.Executar();
            Console.ReadLine();//Manter o Prompt Aberto
        }//fim do método
    }//fim da classe
}//fim do projeto
